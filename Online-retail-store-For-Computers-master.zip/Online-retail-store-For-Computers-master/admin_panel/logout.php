<?php
session_start();
session_destroy();
echo "<script>window.open('login.php?logged_out=You Have LogOut, Come Back Soon!!!','_self')</script>";

?>