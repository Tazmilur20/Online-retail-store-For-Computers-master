<h3>OverView</h3>The name of this project is ‘Online Retail Store For computers’. This is a website that will sell
various kinds of Computer related Products to registered users. The main purpose of this website is to provide computer related products of various kinds to the paying users, as well as provide up-to-date information regarding
the various kind available in the website.

<img align="center" src="rs.png"/>

<h3>Platform:</h3> This website was made using 
<ul style="list-style-type:square">
<li>Code editor : Notepad++ /Sublime Text</li>
<li>Languages : Html, Css, Javascript, Ajax, Php & bootstrap.</li>
<li>Free and open source Web server : Xampp</li>
</ul>


<ul style="list-style-type:circle">
<h3>Author:</h3>
<ul style="list-style-type:square">
<li>Sagor Ahamed</li>
<li>Nabil Ahmed</li>
<li>Md.Golam Rabbani Shuvo</li>
</ul>

<h4>FEATURES:</h4>
This website is embedded with various unique features. All of the features that are present within the software can be categorized into two portions:
<h6> User-side features</h6>
<ul style="list-style-type:circle">
<li>Viewing All products in Front-End Homepage.</li>
<li>Viewing All products in Front-End Homepage By Category / Platform / Developers.</li>
<li>Viewing Specific products by using Advanced Search.</li>
<li>Viewing each individual product with short description.</li>
<li>Adding product to cart direct from Front-End’s homepage or Individual Product Page’s.</li>
<li>Collection of all products in a cart.</li>
<li>Purchase via MasterCard.</li>
<li>Viewing & Editing User Profile Information.</li>
<li>Viewing Order Status.</li>
<li>Applying promo code and get discount on purchase.</li>
<li>Registration & Login.</li>
<li>View F.A.Q</li>
<li>Contact with Admin using help message.</li>
<li>View the news on the latest games and offers.</li>
<li>Suggestions for product in each product pages.</li>
<li>Forget Password Reset</li>
</ul>

<h6> Admin-side features</h6>
The admins may have access to the following features within the software:
<ul style="list-style-type:circle">
  
<li>Admin Panel With Menu.</li>
<li>Admin Login.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Products.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Category.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Brands.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Developers.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Platforms.</li>
<li>Viewing Front-End Direct From Back-End.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Products.</li>
<li>Inserting/ Viewing/ Deleting/ Updating Promo Code.</li>
<li>Inserting/ Viewing/ Deleting/ Updating F.A.Q.</li>
<li>Viewing/ Deleting/ Updating Customer Messages.</li>
<li>Viewing/ Deleting/ Updating Orders.</li>
<li>Replying To Customer Message.</li>
<li>Controlling The User Profile.</li>
<li>Updating News Feed, Header Image, Banner Image, Center Ads Image.</li>
</ul>

And many more....


<footer>This Project is not to be used for any project submission.</footer>
